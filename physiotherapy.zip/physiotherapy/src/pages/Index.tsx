import React, { useState } from 'react';
import { useExerciseData } from '@/hooks/useExerciseData';
import ExerciseCard from '@/components/ExerciseCard';
import ExerciseFilters from '@/components/ExerciseFilters';
import ExerciseModal from '@/components/ExerciseModal';
import { Exercise } from '@/types';
import { Loader2 } from 'lucide-react';
const Index = () => {
  const {
    exercises,
    isLoading,
    error,
    filterOptions,
    activeFilters,
    updateFilter,
    clearFilters,
    applyFilters,
    totalExercises
  } = useExerciseData();
  const [selectedExercise, setSelectedExercise] = useState<Exercise | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const openExerciseModal = (exercise: Exercise) => {
    setSelectedExercise(exercise);
    setModalOpen(true);
  };
  const closeExerciseModal = () => {
    setModalOpen(false);
  };

  // Group exercises by displaySubcategory or subcategory
  const groupedExercises = React.useMemo(() => {
    const groups: Record<string, Exercise[]> = {};
    exercises.forEach(exercise => {
      const subcategory = exercise.displaySubcategory || exercise.subcategory || 'Other';
      if (!groups[subcategory]) {
        groups[subcategory] = [];
      }
      groups[subcategory].push(exercise);
    });
    return groups;
  }, [exercises]);
  return <div className="min-h-screen bg-background">
      <header className="w-full border-b border-border/50 bg-white">
        
      </header>

      <main className="container px-4 py-8">
        <ExerciseFilters filterOptions={filterOptions} activeFilters={activeFilters} updateFilter={updateFilter} clearFilters={clearFilters} applyFilters={applyFilters} />
        
        <div className="mt-8">
          {isLoading ? <div className="flex items-center justify-center h-64">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div> : error ? <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-800">
              <p className="font-medium mb-1">Error loading exercises</p>
              <p className="text-sm">{error}</p>
            </div> : exercises.length === 0 ? <div className="bg-muted/50 border border-border rounded-lg p-8 text-center">
              <h3 className="text-lg font-medium mb-2">No yoga practices found</h3>
              <p className="text-muted-foreground mb-4">
                Try adjusting your filters to find yoga practices.
              </p>
              <button onClick={clearFilters} className="text-primary hover:underline text-sm font-medium">
                Clear all filters
              </button>
            </div> : Object.entries(groupedExercises).map(([subcategory, exerciseList]) => <div key={subcategory} className="mb-10">
                <h2 className="text-xl font-medium mb-4">{subcategory}</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                  {exerciseList.map(exercise => <div key={exercise.id} className="animate-fade-in" style={{
              animationDelay: `${exercise.id % 8 * 50}ms`
            }}>
                      <ExerciseCard exercise={exercise} onClick={() => openExerciseModal(exercise)} />
                    </div>)}
                </div>
              </div>)}
        </div>
      </main>
      
      <ExerciseModal exercise={selectedExercise} isOpen={modalOpen} onClose={closeExerciseModal} />
    </div>;
};
export default Index;