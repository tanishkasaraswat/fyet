import { Heading } from "./Heading";
import { Img } from "./Img";
import { Text } from "./Text";
import { Button } from "./Button";
export { Button, Heading, Img, Text };
import Header from './Header1';
export { Header as Header1 };
import Footer from './Footer1';
export { Footer as Footer1 };