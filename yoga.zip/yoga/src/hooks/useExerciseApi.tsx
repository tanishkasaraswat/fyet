import { useState, useEffect } from 'react';
import { Exercise } from '@/types';
import { toast } from '@/components/ui/use-toast';
import { MOCK_EXERCISES } from '@/data/mockData';
import { YOGA_POSES } from '@/data/YOGA_POSES'; // Import your yoga poses data

export function useExerciseApi(selectedOption: string | null = null) {
  const [exercises, setExercises] = useState<Exercise[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchExercises = async () => {
      setIsLoading(true);
      try {
        if (selectedOption) {
          // When an option is selected, use YOGA_POSES data
          console.log(`Fetching exercises for option: ${selectedOption}`);
          setExercises(YOGA_POSES.filter(pose => 
            pose.category === selectedOption || 
            pose.difficulty === selectedOption
          ));
          toast({
            title: "Yoga Poses Loaded",
            description: `Showing ${selectedOption} poses`,
            variant: "default",
          });
        } else {
          // When no option is selected, use mock data
          console.log("No option selected - using mock data");
          setExercises(MOCK_EXERCISES);
          toast({
            title: "Sample Data",
            description: "No filter selected. Showing sample exercises.",
            variant: "default",
          });
        }
        setError(null);
      } catch (err) {
        console.error('Error processing exercise data:', err);
        setError('Failed to process exercises. Using mock data instead.');
        setExercises(MOCK_EXERCISES);
      } finally {
        setIsLoading(false);
      }
    };

    fetchExercises();
  }, [selectedOption]); // Re-run when selectedOption changes

  return {
    exercises,
    isLoading,
    error,
    totalExercises: exercises.length,
  };
}