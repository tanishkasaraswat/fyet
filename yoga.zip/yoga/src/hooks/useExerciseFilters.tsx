import { useState, useMemo } from 'react';
import { Exercise, ActiveFilters, FilterOptions } from '@/types';
import { MOCK_EXERCISES } from '@/data/mockData';
import { YOGA_POSES } from '@/data/YOGA_POSES';

export function useExerciseFilters() {
  const [activeFilters, setActiveFilters] = useState<ActiveFilters>({
    ageGroup: null,
    days: null,
    difficulty: null,
  });
  
  const [appliedFilters, setAppliedFilters] = useState<ActiveFilters>({
    ageGroup: null,
    days: null,
    difficulty: null,
  });

  // Static filter options (not derived from data)
  const filterOptions: FilterOptions = {
    ageGroup: ['Child', 'Adolescent', 'Adult', 'Old Age'],
    days: [3, 4, 5, 6],
    difficulty: ['Beginner', 'Intermediate', 'Advanced'],
  };

  const filteredExercises = useMemo(() => {
    // When no filters are applied, show only Surya Namaskar and Meditation from MOCK_EXERCISES
    if (!appliedFilters.ageGroup && !appliedFilters.days && !appliedFilters.difficulty) {
      return MOCK_EXERCISES.filter(ex => 
        ex.subcategory === "Meditation" || ex.subcategory === "Surya Namaskar"
      ).map(ex => ({
        ...ex,
        displaySubcategory: "Featured Practices"
      }));
    }
    
    // When filters are applied, show filtered YOGA_POSES
    return YOGA_POSES.filter(exercise => {
      const ageGroupMatch = !appliedFilters.ageGroup || exercise.ageGroup === appliedFilters.ageGroup;
      const daysMatch = !appliedFilters.days || exercise.days === appliedFilters.days;
      const difficultyMatch = !appliedFilters.difficulty || exercise.difficulty === appliedFilters.difficulty;
      
      return ageGroupMatch && daysMatch && difficultyMatch;
    });
  }, [appliedFilters]);

  const updateFilter = (filterType: keyof ActiveFilters, value: string | null | number) => {
    const normalizedValue = value === "any" ? null : value;
    
    setActiveFilters(prev => ({
      ...prev,
      [filterType]: normalizedValue
    }));
  };

  const applyFilters = () => {
    setAppliedFilters(activeFilters);
  };

  const clearFilters = () => {
    const emptyFilters = {
      ageGroup: null,
      days: null,
      difficulty: null,
    };
    
    setActiveFilters(emptyFilters);
    setAppliedFilters(emptyFilters);
  };

  return {
    filterOptions,
    activeFilters,
    filteredExercises,
    updateFilter,
    applyFilters,
    clearFilters,
    filteredCount: filteredExercises.length,
  };
}