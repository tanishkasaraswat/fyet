
import { Exercise } from '@/types';

// Mock data for exercises when API fails
export const MOCK_EXERCISES: Exercise[] = [
  {
    id: 1,
    name: "Surya Namaskar",
    image: "https://images.unsplash.com/photo-1575052814086-f385e2e2ad1b",
    instructions: "Start with mountain pose. Raise your arms, bend forward, step back into a lunge, move to plank, lower to the floor, perform cobra, downward dog, step forward, bend forward, raise arms, return to mountain pose.",
    precautions: "Take it slow and don't push yourself too hard at first.",
    youtubeLink: "https://www.youtube.com/watch?v=YqOqM79McYY",
    duration: 30,
    category: "Yoga",
    difficulty: "Beginner",
    bodyFocus: "Full Body",
    days: 3,
    ageGroup: "Adult",
    subcategory: "Surya Namaskar"
  },
  {
    id: 2,
    name: "Meditation",
    image: "https://images.unsplash.com/photo-1599447332412-6bc6830c815a",
    instructions: "Find a quiet place. Sit in a comfortable position. Close your eyes and focus on your breath.",
    precautions: "Find a quiet space where you won't be disturbed.",
    youtubeLink: "https://www.youtube.com/watch?v=4Ejz7IgODlU",
    duration: 45,
    category: "Yoga",
    difficulty: "Beginner",
    bodyFocus: "Mind",
    days: 7,
    ageGroup: "Adult",
    subcategory: "Meditation"
  },
]