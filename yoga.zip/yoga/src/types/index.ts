
export interface Exercise {
  id: number;
  name: string;
  image: string;
  instructions: string;
  precautions: string;
  youtubeLink: string;
  duration: number;
  category: 'Yoga' | 'Exercise';
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  bodyFocus: string;
  days?: number;
  ageGroup?: 'Child' | 'Adolescent' | 'Adult' | 'Old Age';
  subcategory?: string;
  displaySubcategory?: string;
}

export interface AudioOption {
  id: string;
  name: string;
  url: string;
}

export type FilterOptions = {
  ageGroup: string[];
  days: number[];
  difficulty: string[];
}

export type ActiveFilters = {
  ageGroup: string | null;
  days: number | null;
  difficulty: string | null;
}
