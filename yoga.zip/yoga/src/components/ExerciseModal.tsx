import React, { useState, useEffect, useRef } from 'react';
import { Exercise, AudioOption } from '../types';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { ExternalLink, Youtube, Play, Pause, Volume2, Timer as TimerIcon, AlertTriangle } from "lucide-react";
import Timer from './Timer';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const MEDITATION_AUDIO_OPTIONS: AudioOption[] = [
  {
    id: 'nature',
    name: 'Nature Sounds',
    url: '/audio/nature.mp3'
  },
  {
    id: 'rain',
    name: 'Rain Sounds',
    url: '/audio/rain.mp3'
  },
  {
    id: 'waves',
    name: 'Ocean Waves',
    url: '/audio/waves.mp3'
  },
  {
    id: 'river',
    name: 'River Sounds',
    url: '/audio/forest.mp3'
  },
  {
    id: 'birds',
    name: 'Birds Chirping',
    url: '/audio/birds.mp3'
  },
  {
    id: 'wind',
    name: 'Wind Sounds',
    url: '/audio/wind.mp3'
  },
];

interface ExerciseModalProps {
  exercise: Exercise | null;
  isOpen: boolean;
  onClose: () => void;
}

const ExerciseModal: React.FC<ExerciseModalProps> = ({ exercise, isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState("instructions");
  const [selectedAudio, setSelectedAudio] = useState<AudioOption | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(0.5);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    if (!isOpen || !exercise) {
      setSelectedAudio(null);
      setIsPlaying(false);
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.currentTime = 0;
      }
    }
  }, [isOpen, exercise]);

  useEffect(() => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.play().catch(e => console.error("Error playing audio:", e));
      } else {
        audioRef.current.pause();
      }
    }
  }, [isPlaying, selectedAudio]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
    }
  }, [volume]);

  const handleAudioSelect = (audioId: string) => {
    const selected = MEDITATION_AUDIO_OPTIONS.find(option => option.id === audioId);
    if (audioRef.current && isPlaying) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      setIsPlaying(false);
    }
    setSelectedAudio(selected || null);
  };

  const togglePlayPause = () => {
    if (selectedAudio) {
      setIsPlaying(!isPlaying);
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setVolume(parseFloat(e.target.value));
  };

  const handleOpenYoutube = () => {
    if (exercise) {
      window.open(exercise.youtubeLink, '_blank', 'noopener,noreferrer');
    }
  };

  if (!exercise) return null;

  const isMeditation = exercise.subcategory.toLowerCase().includes('meditation');

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[700px] p-0 overflow-hidden">
        <div className="relative w-full h-[300px] overflow-hidden">
          <img 
            src={exercise.image} 
            alt={exercise.name} 
            className="w-full h-full object-cover"
            onError={(e) => {
              (e.target as HTMLImageElement).src = '/default-yoga-thumbnail.jpg';
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/30 to-transparent" />
          
          <Button 
            variant="ghost" 
            size="icon" 
            className="absolute top-4 right-4 z-20 rounded-full bg-white/20 backdrop-blur-sm hover:bg-white/30"
            onClick={onClose}
          >
            ✕
          </Button>
          
          <div className="absolute bottom-4 left-4 z-20 flex gap-2">
            <span className={`px-3 py-1 rounded-full text-sm font-medium ${
              exercise.difficulty === 'Beginner' ? 'bg-green-100 text-green-800' :
              exercise.difficulty === 'Intermediate' ? 'bg-blue-100 text-blue-800' :
              'bg-red-100 text-red-800'
            }`}>
              {exercise.difficulty}
            </span>
            <span className="px-3 py-1 rounded-full text-sm font-medium bg-secondary text-secondary-foreground">
              {exercise.bodyFocus}
            </span>
          </div>
          
          <Button 
            variant="outline" 
            size="sm" 
            className="absolute bottom-4 right-4 z-20 bg-white/20 backdrop-blur-sm hover:bg-white/30"
            onClick={handleOpenYoutube}
          >
            <Youtube className="h-4 w-4 mr-2" />
            Watch Video
          </Button>
        </div>
        
        <div className="p-6">
          <DialogHeader>
            <DialogTitle className="text-3xl font-bold">{exercise.name}</DialogTitle>
            <DialogDescription className="mt-2 text-gray-600">
              {exercise.subcategory} • {exercise.duration} seconds
            </DialogDescription>
          </DialogHeader>

          {isMeditation && (
            <div className="mt-4 bg-gray-50 p-4 rounded-lg">
              <h3 className="font-semibold text-lg mb-3">Meditation Audio</h3>
              <div className="flex items-center gap-4">
                <Select onValueChange={handleAudioSelect}>
                  <SelectTrigger className="w-[200px]">
                    <SelectValue placeholder="Select background audio" />
                  </SelectTrigger>
                  <SelectContent>
                    {MEDITATION_AUDIO_OPTIONS.map((option) => (
                      <SelectItem key={option.id} value={option.id}>
                        {option.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                {selectedAudio && (
                  <>
                    <Button 
                      variant="outline" 
                      size="icon" 
                      onClick={togglePlayPause}
                      disabled={!selectedAudio}
                    >
                      {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                    </Button>
                    
                    <div className="flex items-center gap-2">
                      <Volume2 className="h-4 w-4 text-gray-500" />
                      <input
                        type="range"
                        min="0"
                        max="1"
                        step="0.01"
                        value={volume}
                        onChange={handleVolumeChange}
                        className="w-24"
                      />
                    </div>
                  </>
                )}
              </div>
              <audio 
                ref={audioRef} 
                src={selectedAudio?.url} 
                loop 
                onEnded={() => setIsPlaying(false)}
              />
            </div>
          )}

          <Tabs defaultValue="instructions" className="mt-6">
            <TabsList className="grid grid-cols-2 w-[200px] mb-6">
              <TabsTrigger value="instructions">Instructions</TabsTrigger>
              <TabsTrigger value="timer">
                <TimerIcon className="h-4 w-4 mr-2" />
                Timer
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="instructions" className="space-y-6">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="font-semibold text-lg mb-3">Step-by-Step Instructions</h3>
                <div className="whitespace-pre-line text-gray-700">
                  {exercise.instructions}
                </div>
              </div>
              
              <div className="bg-red-50 p-4 rounded-lg">
                <h3 className="font-semibold text-lg mb-3 flex items-center">
                  <AlertTriangle className="h-5 w-5 mr-2 text-red-500" />
                  Precautions
                </h3>
                <div className="whitespace-pre-line text-gray-700">
                  {exercise.precautions}
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="timer">
              <Timer defaultDuration={exercise.duration} />
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ExerciseModal;