import React from 'react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { FilterOptions, ActiveFilters } from '../types';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { X } from 'lucide-react';

interface ExerciseFiltersProps {
  filterOptions: FilterOptions;
  activeFilters: ActiveFilters;
  updateFilter: (filterType: keyof ActiveFilters, value: string | null | number) => void;
  clearFilters: () => void;
  applyFilters: () => void;
}

const ExerciseFilters: React.FC<ExerciseFiltersProps> = ({
  filterOptions,
  activeFilters,
  updateFilter,
  clearFilters,
  applyFilters
}) => {
  const hasActiveFilters = Object.values(activeFilters).some(value => value !== null);

  return (
    <div className="w-full animate-fade-in">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-2xl font-medium">Filters</h3>
        
        {hasActiveFilters && (
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={clearFilters}
            className="text-sm h-9 px-3 text-primary hover:text-primary flex items-center gap-1"
          >
            <X size={16} />
            Clear all
          </Button>
        )}
      </div>
      
      <div className="flex flex-wrap gap-4 mb-6">
        <div className="min-w-[200px]">
          <Select 
            value={activeFilters.difficulty?.toString() || ""} 
            onValueChange={value => updateFilter('difficulty', value || null)}
          >
            <SelectTrigger className="w-full h-12">
              <SelectValue placeholder="Difficulty" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="any">All Levels</SelectItem>
              {filterOptions.difficulty.map(level => (
                <SelectItem key={level} value={level}>{level}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <div className="min-w-[200px]">
          <Select 
            value={activeFilters.ageGroup?.toString() || ""} 
            onValueChange={value => updateFilter('ageGroup', value || null)}
          >
            <SelectTrigger className="w-full h-12">
              <SelectValue placeholder="Age Group" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="any">All Ages</SelectItem>
              {filterOptions.ageGroup.map(age => (
                <SelectItem key={age} value={age}>{age}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <div className="min-w-[200px]">
          <Select 
            value={activeFilters.days?.toString() || ""} 
            onValueChange={value => updateFilter('days', value ? parseInt(value) : null)}
          >
            <SelectTrigger className="w-full h-12">
              <SelectValue placeholder="Days per Week" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="any">Any Frequency</SelectItem>
              {filterOptions.days.map(day => (
                <SelectItem key={day} value={day.toString()}>{day} Days</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <Button 
          onClick={applyFilters} 
          className="rounded-full min-w-[150px] h-12 text-base bg-orange-600 hover:bg-orange-500 transition-colors"
        >
          Apply Filters
        </Button>
      </div>
    </div>
  );
};

export default ExerciseFilters;