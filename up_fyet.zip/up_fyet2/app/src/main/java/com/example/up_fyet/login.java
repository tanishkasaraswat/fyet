package com.example.up_fyet;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

public class login extends AppCompatActivity {

    private static final int SPLASH_SCREEN_TIME_OUT = 4000;
    Animation round,left,right;
    View main_s;
    TextView tex_1,tex_2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_login);
        round= AnimationUtils.loadAnimation(this,R.anim.zoom_out);
        left=AnimationUtils.loadAnimation(this,R.anim.left_in);
        right=AnimationUtils.loadAnimation(this,R.anim.right_in);
        main_s=findViewById(R.id.imageView3);
        main_s.setAnimation(round);
        tex_1=findViewById(R.id.textView4);
        tex_2=findViewById(R.id.textView5);
        tex_1.setAnimation(left);
        tex_2.setAnimation(right);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent i;
                i = new Intent(getApplicationContext(),menu_page.class);
                startActivity(i);
                //intent for second page
                finish(); // the current activity will get finished.
            }
        }, SPLASH_SCREEN_TIME_OUT);

    }
}