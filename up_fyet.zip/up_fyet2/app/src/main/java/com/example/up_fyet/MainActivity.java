package com.example.up_fyet;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private static final int SPLASH_SCREEN_TIME_OUT = 5000;
    Animation top,bottom,right,left;
    View main_s,go_s;
    TextView tex_1,tex_2,tex_3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);

        top= AnimationUtils.loadAnimation(this,R.anim.top_in);
        bottom=AnimationUtils.loadAnimation(this,R.anim.bottom_in);
        left=AnimationUtils.loadAnimation(this,R.anim.left_in);
        right=AnimationUtils.loadAnimation(this,R.anim.right_in);

        main_s=findViewById(R.id.imageView);
        go_s=findViewById(R.id.imageView2);
        tex_1=findViewById(R.id.textView);
        tex_2=findViewById(R.id.textView2);
        tex_3=findViewById(R.id.textView3);

        main_s.setAnimation(bottom);
        go_s.setAnimation(right);
        tex_1.setAnimation(top);
        tex_2.setAnimation(left);
        tex_3.setAnimation(left);


        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent i ;
                i = new Intent(MainActivity.this, login.class);
                startActivity(i);
                //intent for second page
                finish(); // the current activity will get finished.
            }
        }, SPLASH_SCREEN_TIME_OUT);

    }
}