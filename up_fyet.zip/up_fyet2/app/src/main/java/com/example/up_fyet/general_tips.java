package com.example.up_fyet;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class general_tips extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_general_tips);
    }
}