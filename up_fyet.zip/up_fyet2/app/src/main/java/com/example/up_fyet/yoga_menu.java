package com.example.up_fyet;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;

public class yoga_menu extends AppCompatActivity {

    ImageButton surya,anulom,bitil,ujjayi,vir;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_yoga_menu);
        surya=findViewById(R.id.imageButton11);
        anulom=findViewById(R.id.imageButton6);
        bitil=findViewById(R.id.imageButton8);
        ujjayi=findViewById(R.id.imageButton10);
        vir=findViewById(R.id.imageButton9);
        surya.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i ;
                i = new Intent(yoga_menu.this, yoga_menu.class);
                startActivity(i);
            }
        });
        anulom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i ;
                i = new Intent(yoga_menu.this, yoga_menu.class);
                startActivity(i);
            }
        });
        bitil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i ;
                i = new Intent(yoga_menu.this, yoga_menu.class);
                startActivity(i);
            }
        });
        ujjayi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i ;
                i = new Intent(yoga_menu.this, yoga_menu.class);
                startActivity(i);
            }
        });
        vir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i ;
                i = new Intent(yoga_menu.this, yoga_menu.class);
                startActivity(i);
            }
        });
    }
}