package com.example.up_fyet;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;

public class exercise_menu extends AppCompatActivity {

    ImageButton neck,shoulder,wrist,ankle,knee;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_exercise_menu);
        neck=findViewById(R.id.imageButton11);
        shoulder=findViewById(R.id.imageButton6);
        wrist=findViewById(R.id.imageButton8);
        knee=findViewById(R.id.imageButton10);
        ankle=findViewById(R.id.imageButton9);
        neck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i ;
                i = new Intent(exercise_menu.this, exercise_menu.class);
                startActivity(i);
            }
        });
        shoulder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i ;
                i = new Intent(exercise_menu.this, exercise_menu.class);
                startActivity(i);
            }
        });
        wrist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i ;
                i = new Intent(exercise_menu.this, exercise_menu.class);
                startActivity(i);
            }
        });
        knee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i ;
                i = new Intent(exercise_menu.this, exercise_menu.class);
                startActivity(i);
            }
        });
        ankle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i ;
                i = new Intent(exercise_menu.this, exercise_menu.class);
                startActivity(i);
            }
        });
    }
}