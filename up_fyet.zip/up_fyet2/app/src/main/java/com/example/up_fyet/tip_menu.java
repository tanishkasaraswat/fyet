package com.example.up_fyet;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;

public class tip_menu extends AppCompatActivity {

    ImageButton general,neck,shoulder,wrist,ankle,knee;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_tip_menu);
        general=findViewById(R.id.imageButton11);
        neck=findViewById(R.id.imageButton6);
        shoulder=findViewById(R.id.imageButton8);
        wrist=findViewById(R.id.imageButton10);
        knee=findViewById(R.id.imageButton9);
        ankle=findViewById(R.id.ankle_tip);
        general.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i ;
                i = new Intent(tip_menu.this, general_tips.class);
                startActivity(i);
            }
        });
        neck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i ;
                i = new Intent(tip_menu.this, neck_tips.class);
                startActivity(i);
            }
        });
        shoulder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i ;
                i = new Intent(tip_menu.this, shoulder_tips.class);
                startActivity(i);
            }
        });
        wrist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i ;
                i = new Intent(tip_menu.this, wrist_related.class);
                startActivity(i);
            }
        });
        ankle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i ;
                i = new Intent(tip_menu.this, knee_related.class);
                startActivity(i);
            }
        });
        knee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i ;
                i = new Intent(tip_menu.this, ankle_related.class);
                startActivity(i);
            }
        });

    }
}