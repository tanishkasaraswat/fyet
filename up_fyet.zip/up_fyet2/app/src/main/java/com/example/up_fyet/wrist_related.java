package com.example.up_fyet;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class wrist_related extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wrist_related);
    }
}