package com.example.up_fyet;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;

public class menu_page extends AppCompatActivity {

    ImageButton yoga,exercise,tips;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_menu_page);
        yoga=findViewById(R.id.imageButton2);
        exercise=findViewById(R.id.imageButton);
        tips=findViewById(R.id.imageButton3);
        yoga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i ;
                i = new Intent(menu_page.this, yoga_menu.class);
                startActivity(i);
            }
        });

        tips.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i ;
                i = new Intent(menu_page.this, tip_menu.class);
                startActivity(i);
            }
        });
        exercise.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i ;
                i = new Intent(menu_page.this, exercise_menu.class);
                startActivity(i);
            }
        });
    }
}